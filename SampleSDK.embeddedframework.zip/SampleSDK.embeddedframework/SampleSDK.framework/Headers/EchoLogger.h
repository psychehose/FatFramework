//
//  EchoLogger.h
//  SampleSDK
//
//  Created by 김호세 on 10/17/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EchoLogger : NSObject

- (void)helloWithText:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
